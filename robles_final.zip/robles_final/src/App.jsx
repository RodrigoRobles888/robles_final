
import "./App.css"
import { BrowserRouter as Router, Routes, Route } from "react-router-dom"
import Footer from "./componentes/footer/footer";
import Header from "./componentes/header/Header";
import Menu from "./componentes/menu/menu";
import Seccion from "./componentes/section/Seccion";
import ListaCasas from "./componentes/casas/ListaCasas";
import Contacto from "./componentes/contacto/Contacto";



function App() {

  return (
    <Router>
      <div className="container">
        <Header  />
        <Menu />
        <main>
          <Routes>
            <Route path="/" element={<Seccion />} />
            <Route path="/casas" element={<ListaCasas />} />
            <Route path="/contacto" element={ <Contacto />} />
            
          </Routes>
        </main>
        <Footer /> 
      </div>
    </Router>
   );
}


export default App;