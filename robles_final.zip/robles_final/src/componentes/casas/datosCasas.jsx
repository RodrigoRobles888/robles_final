const casas = [
    {
        nombre: "Casa Bal",
        proyecto: "Residencia Privada",
        ubicacion: "El Yatch, Nordelta, Buenos Aires",
        superficie: "880 m2",
        precio: "$500.000 ",
        imagen: " images/Bal.jpg ",
    },

    {
        nombre: "Casa Zetta",
        proyecto: "Residencia Privada",
        ubicacion: "Virazón, Nordelta, Buenos Aires",
        superficie: "530 m2",
        precio: "$200.000 ",
        imagen: " images/Zetta.jpg ",
    },

    {
        nombre: "Casa Búnker",
        proyecto: "Residencia Privada",
        ubicacion: "Cabos, Tigre, Buenos Aires",
        superficie: "700 m2",
        precio: "$350.000 ",
        imagen: " images/Búnker.jpg ",
    },
    

    {
        nombre: "Casa Carrara",
        proyecto: "Residencia Privada",
        ubicacion: "Pilar, Buenos Aires",
        superficie: "660 m2",
        precio: "$300.000 ",
        imagen: " images/Carrara.jpg ",
    },
    
];

export default casas;

