import Casa from './Casa';
import casas from './datosCasas';

function ListaCasas() {
    return (
        <div >
            {casas.map((casa, index) => (
                <Casa
                    key={index}
                    nombre={casa.nombre}
                    proyecto={casa.proyecto}
                    ubicacion={casa.ubicacion}
                    superficie={casa.superficie}
                    precio={casa.precio}
                    imagen={casa.imagen}
                />
            ))}
        </div>
    );
}

export default ListaCasas;