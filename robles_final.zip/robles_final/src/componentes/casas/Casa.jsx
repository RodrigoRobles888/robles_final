function Casa (props) {
    return (
        <section className="seccion">
            <h2> {props.nombre} </h2>
            <p> {props.proyecto} </p>
            <p> {props.ubicacion} </p>
            <p> {props.superficie} </p>
            <p> {props.precio} </p>
            <img src={props.imagen} alt={props.nombre} />
        
            
            

        </section>
    );
}

export default Casa;
