import "./Seccion.css";
import Hogar from "../../assets/img/Hogar.jpg";
import Boton from "../boton/Boton";
import ListaCasas from "../casas/ListaCasas";



const handlerClicBoton = () => {
    alert("Información enviada");
} 
const handlerClickBoton = () => {
    alert("Su suscriocion fue exitosa");
} 


function Seccion() {
    return (
        <section className="seccion">
            <img src={Hogar} alt="Hogar" />

            <h2>Información sobre Nostros</h2>
            <p> Nos especialimos en Viviendas unifamiliares </p>


            <table className="contacto">
                <label> Nombre: </label>
                <input type="texto" />
                <hr />
                <label> Apellido: </label>
                <input type="texto" />
                <hr />
                <label> Celular: </label>
                <input type="number" />
                <hr />
                <Boton texto="Enviar" onClick={handlerClicBoton} />
                
            </table>

             <p> SUSCRIBITE A MI LISTA DE CORREO </p>
            <table className="contacto">
                <label> Email : </label>
                <input type="texto" />
                
                <Boton texto="Suscribirme" onClick={handlerClickBoton} />

            </table>



        
            
        
        </section>
    )
}

export default Seccion;