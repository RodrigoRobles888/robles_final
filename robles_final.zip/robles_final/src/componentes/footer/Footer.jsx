import "./Footer.css";

function Footer() {

    return (
        <header className="footer">
            <p>UBICACION: Argentina, Buenos Aires, Pilar.</p>
            
            <p>Derechos reservados 2024</p>

        </header>
    )
}

export default Footer;