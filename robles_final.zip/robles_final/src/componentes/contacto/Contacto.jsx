import Boton from "../boton/Boton";


const Contacto = () => {
    return (
        <section>
            <table className="contacto">
                <label> Nombre: </label>
                <input type="texto" />
                <hr />
                <label> Apellido: </label>
                <input type="texto" />
                <hr />
                <label> Email: </label>
                <input type="email" />
                <hr />
                <label> Celular: </label>
                <input type="number" />
                <hr />
                <Boton texto="Suscribirme" onClick={handlerClicBoton} />

            </table>
        </section >
    );
}
export default Contacto;